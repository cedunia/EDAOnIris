#
# This is the user-interface definition of a Shiny web application. You can
# run the application by clicking 'Run App' above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)
library(shinydashboard)
library(shinyWidgets)
library(plotly)
library(googleVis)
library(DT)

# Define UI for application that draws a histogram
dashboardPage(
  dashboardHeader(title = "Exploratory Data Analysis on Iris Dataset"),
  dashboardSidebar(
    sidebarMenu(id = "tabs",
      menuItem("Lecture des données", tabName = "readData", icon = icon("readme")),
      menuItem("Visualisation des données", tabName = "visualization", icon = icon("poll"))
    )
  ),
  dashboardBody(
    tabItems(
      # Read data
      tabItem(tabName = "readData",
              h1("Lecture des données"),
              fileInput("dataFile", label = NULL,
                        buttonLabel = "Browse...",
                        placeholder = "No file selected"
              ),
              fluidRow(
                column(3,
                       h3("Parameters"),
                       
                       #Input: Checkbox if file has header
                       radioButtons(inputId = "header",
                                    label = "Header",
                                    choices = c("Yes" = TRUE,
                                                "No" = FALSE),
                                    selected = TRUE, inline = T
                       ),
                       #Input: Select separator ----
                       radioButtons(inputId = "sep",
                                    label = "Separator",
                                    choices = c(Comma = ",",
                                                Semicolon = ";",
                                                Tab = "\t"),
                                    selected = "\t", inline = T
                       ),
                       # Input: Select quotes ----
                       radioButtons(inputId = "quote", 
                                    label= "Quote",
                                    choices = c(None = "",
                                                "Double Quote" = '"',
                                                "Single Quote" = "'"),
                                    selected = "", inline=T
                       )
                ),
                column(9,
                       h3("File preview"),
                       dataTableOutput(
                         outputId = "preview"
                       )
                )
              ),
              tags$br(),
              div(actionButton(inputId = "actBtnVisualisation", 
                               label = "Visualisation",icon = icon("play")), 
                  align = "center")

      ),
      # visualization
      tabItem(tabName = "visualization",
              h1("Visualisation des données"),
              h2("Exploration du tableau"),
              dataTableOutput('dataTable'),
              h2("Graphiques"),
              fluidRow(
                column(4, plotOutput("plotAvecR")),
                column(4, colourpicker::colourInput("colR", "Couleur graphique R", "black",allowTransparent = T),
                       sliderInput("cex", "Taille",
                                   min = 0.5, max = 3,
                                   value = 1,step = 0.2
                       )),
                column(4, selectInput(inputId = "pch", choices = 1:20, label = "Type de points",selected = 1),
                       textInput("title", "Titre", "Sepal length vs Petal length (R)") )
              ),
              tags$br(), 
              fluidRow(
                column(4, plotOutput("plotAvecGgplot2")),
                column(4, plotlyOutput("plotAvecPlotly")),
                column(4, htmlOutput("plotAvecGoogle"))
              )
      )
    )
  )
)